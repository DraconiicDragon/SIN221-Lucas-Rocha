float modulo(float valor1) {
    if(valor1 < 0) {
        return -valor1;
    }
    return valor1;
}
float soma(float valor1, float valor2) {
    return valor1 + valor2;
}
float subtracao(float valor1, float valor2) {
    return valor1 - valor2;
}
float divisao(float valor1, float valor2) {
    return valor1 / valor2;
}
float multiplicacao(float valor1, float valor2) {
    return valor1 * valor2;
}


