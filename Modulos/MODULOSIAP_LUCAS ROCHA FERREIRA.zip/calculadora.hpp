#ifndef CALCULADORA_H
#define CALCULADORA_H

#include "calculadora.cpp"

float modulo(float valor1);
float soma(float valor1, float valor2);
float subtracao(float valor1, float valor2);
float multiplicacao(float valor1, float valor2);
float divisao(float valor1, float valor2);

#endif